import React from "react";
import { render, fireEvent, waitFor, screen } from "@testing-library/react";
import App from "./App"; 

describe("App Component", () => {
  beforeEach(() => {
    render(<App />);
  });

  test("renders the New Chat button", () => {
    const newChatButton = screen.getByText("+ New Chat");
    expect(newChatButton).toBeInTheDocument();
  });

  test("clicking on New Chat button should clear the chat", () => {
    const newChatButton = screen.getByText("+ New Chat");
    fireEvent.click(newChatButton);

    const chatTitle = screen.queryByText("Test Title");
    expect(chatTitle).not.toBeInTheDocument();
  });

  test("renders the chat history", () => {
    const chatHistory = screen.getByText("Test Title");
    expect(chatHistory).toBeInTheDocument();
  });

  test("clicking on a chat title should display the chat messages", () => {
    const chatTitle = screen.getByText("Test Title");
    fireEvent.click(chatTitle);

    const userMessage = screen.getByText("user: Test Content");
    expect(userMessage).toBeInTheDocument();
  });

  test("typing in the input field and clicking submit should fetch messages", async () => {
    const inputField = screen.getByRole("textbox");
    fireEvent.change(inputField, { target: { value: "Test Message" } });

    const submitButton = screen.getByText("➢");
    fireEvent.click(submitButton);

    await waitFor(() => {
      const userMessage = screen.getByText("user: Test Message");
      expect(userMessage).toBeInTheDocument();
    });
  });
});
